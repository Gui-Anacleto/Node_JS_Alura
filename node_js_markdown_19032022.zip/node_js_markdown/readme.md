1. Criando um projeto em NodeJS(npm init, npm/yarn, markdown, install dependecias, ESM/CJS, exports modules)

    Que para criar um projeto em NodeJs utilizamos o comando npm init;

    Que o arquivo package.json é utilizado pelo NodeJS para listar as dependências instaladas, além de informações sobre versão do programa, autoria e scripts;

    Que as dependências (também chamadas de libs ou bibliotecas) são pacotes de código pronto que outras pessoas da comunidade disponibilizam, e nós as utilizamos para executar tarefas específicas no código sem termos que reescrever do zero;

    Que para deixar o código mais organizado podemos usar ferramentas de linting, além da importância delas para reforçar estilo e também para prever possíveis bugs.

2. Carregamento de arquivos(FS,Tratamento de erros, promessas, .then(), async/await, construtor new Promise(), try/catch/finally)

    Que podemos utilizar a lib fs (File System, ou sistema de arquivos) nativa do JavaScript para que o programa consiga acessar e ler arquivos do computador;

    Que conseguimos capturar mensagens de erro enviadas pelo NodeJS quando algo no programa não sai como o esperado utilizando a palavra-chave throw, ou lançar;

    Que as “promessas” são a forma que o JavaScript utiliza para trabalhar com código assíncrono e que podemos resolvê-las utilizando em conjunto as palavras-chave async e await ou o método .then().