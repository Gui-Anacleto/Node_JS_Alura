const chalk = require('chalk'); //externa
const fs = require('fs'); //nativa

console.log(chalk.blue('vamos começar!')); 

function trataErro(erro){
  throw new Error(chalk.red(erro.code, 'Não há arquivo no diretório'));//lançar - lança o erro 
}

async function pegaArquivo(path_arquivo){
  const encoding = "utf-8";
  //tenta
  try{
    const texto = await fs.promises.readFile(path_arquivo, encoding);
    console.log(chalk.green(texto));
  }
  //se não der pega o erro
  catch(erro){
    trataErro(erro);
  }
  finally{
    console.log(chalk.yellow('operação concluída'));
  }
    
}

pegaArquivo('./arquivos/texto1.md'); 
/* function pegaArquivo(path_arquivo){
  const encoding = "utf-8";
  fs.promises
  .readFile(path_arquivo, encoding)
  .then((texto) => console.log(chalk.green(texto))) //then - Então [callback] - passa para frente
  .catch((erro) => trataErro(erro)) //pegar - pegar o erro e passar para function
}*/

/* function pegaArquivo(path_arquivo){
  const encoding = 'utf-8;'
  fs.readFile(path_arquivo, encoding, (erro, texto) => {

      if(erro){
        trataErro(erro);
      }

      console.log(chalk.green(texto))
  })
} */



